.NET CMS 3.99
http://www.cmsaspnet.com/

� 2002 By Andrea Bruno
Free support: Andrea_Bruno@hotmail.com

DESCRIPTION 1.0
CMS ASP NET - The Website Creator - is a easy and powerful website builder platform designed for windows hosting


TERMS & CONDITIONS
This application must be redistributed with this document unchanged


LICENSE 1.0
1) This application is free
2) This application is free redistributable
3) This application is open source (free modifiable)
4) This source code is not usable in other applications

ADD-ONS:
TinyMCE � http://tinymce.moxiecode.com/
jscolor � http://jscolor.com/